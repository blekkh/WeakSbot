using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceretLevelScript : MonoBehaviour
{

    public newTransition trans;
    private bool canEnterDoor;

    private SelectLevel selectLevel;

    private SpriteRenderer sprite;
    public Sprite OpenDoor;

    public void EnterDoor()
    {
        canEnterDoor = true;
    }

    private void Start()
    {
        sprite = GetComponent<SpriteRenderer>();
    }

    private void Update()
    {
        selectLevel = FindObjectOfType<SelectLevel>();

        if(selectLevel.newUnlockedLevels > 10)
        {
            sprite.sprite = OpenDoor;
            canEnterDoor = true;
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (canEnterDoor)
        {
            trans.FadeOut("endScene");
        }
    }
}
