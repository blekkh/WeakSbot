using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSprite : MonoBehaviour
{

    private PlayerBase playerBase;

    private float aimingAngle;

    // Start is called before the first frame update
    void Start()
    {
        playerBase = GetComponentInParent<PlayerBase>();
    }

    // Update is called once per frame
    void Update()
    {
        aimingAngle = playerBase.weaponAngle;
    }
}
