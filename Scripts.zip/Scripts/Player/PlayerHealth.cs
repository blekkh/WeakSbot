using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    private PlayerBase _base;

    public float maxHealth;
    public float currentHealth;
    public float invCooldown;
    private float currentInvCooldown;

    public Image[] hearts;
    public Sprite fullHeart;
    public Sprite emptyHeart;

    public SpriteRenderer playerSprite;
    Material currentMat;
    public Material flashMat;
    public float flashTime;
    private float currentFlashTime;
    public Animator anim;

    public CameraShake camShake;

    private float currentStunTime;

    private Rigidbody2D rb;

    private PlayerDash _dash;


    public ParticleSystem onDeathBurnParticle;
    public ParticleSystem onDeathExplodeParticle;
    public ParticleSystem onDeathExplodeParticle2;
    public ParticleSystem onDeathExplodeParticle3;
    private newTransition transition;

    public GameObject gasParticle;

    public GameObject healthCanvas;

    private PlayerUpgrades playerUpgrades;

    public AudioSource hitSound;
    public AudioSource dieSound;





    private void Start()
    {

        playerUpgrades = FindObjectOfType<PlayerUpgrades>();

        if (playerUpgrades != null)
            switch (playerUpgrades.currentHealthUpgrades)
            {
                case 0:
                    maxHealth = 1;
                    break;
                case 1:
                    maxHealth = 2;
                    break;
                case 2:
                    maxHealth = 3;
                    break;
                case 3:
                    maxHealth = 4;
                    break;
                case 4:
                    maxHealth = 5;
                    break;
                case 5:
                    maxHealth = 6;
                    break;
                case 6:
                    maxHealth = 7;
                    break;
                case 7:
                    maxHealth = 8;
                    break;
                case 8:
                    maxHealth = 9;
                    break;
                case 9:
                    maxHealth = 10;
                    break;
                case 10:
                    maxHealth = 11;
                    break;
            }

        _base = GetComponent<PlayerBase>();
        currentMat = playerSprite.material;
        rb = GetComponent<Rigidbody2D>();
        _dash = GetComponent<PlayerDash>();
        currentHealth = maxHealth;
        transition = FindObjectOfType<newTransition>();

        for (int i = 0; i < hearts.Length; i++)
        {
            if (i < maxHealth)
            {
                hearts[i].enabled = true;
            }
            else
            {
                hearts[i].enabled = false;
                healthCanvas.GetComponent<RectTransform>().anchoredPosition += new Vector2(15, 0);

            }
        }
       
    }

    private void Update()
    {

      


        for (int i = 0; i < hearts.Length; i++)
        {
            if(i < currentHealth)
            {
                hearts[i].sprite = fullHeart;
            } else
            {
                hearts[i].sprite = emptyHeart;
            }

        }


            if (currentInvCooldown > 0)
        {
            currentInvCooldown -= Time.deltaTime;
        }


        Flash();


        if (_base.isStunned && currentStunTime > 0)
        {
            currentStunTime -= Time.deltaTime;
            _base.isStunned = true;

        } else
        {
            _base.isStunned = false;
            rb.drag = 0;
        }
    }



    public void TakeDamange(float healthAmmount)
    {
        if (currentInvCooldown <= 0 && !_base.isDead)
        {
            anim.SetTrigger("isHit");
            currentInvCooldown = invCooldown;

            currentHealth -= healthAmmount;

            if (currentHealth <= 0)
            {
                StartCoroutine(onDeath());
            }

            hitSound.Play();

            currentFlashTime = flashTime;


            camShake.DoNoise(3, 3, 0.4f);
        }

    }

    private IEnumerator onDeath()
    {

        _base.isDead = true;

        camShake.DoNoise(4, 4, 0.2f);

        Instantiate(onDeathBurnParticle,transform.position, Quaternion.identity);

        yield return new WaitForSecondsRealtime(0.5f);

        Instantiate(onDeathExplodeParticle2, transform.position, Quaternion.identity);
        Instantiate(onDeathExplodeParticle, transform.position, Quaternion.identity);
        Instantiate(onDeathExplodeParticle3, transform.position, Quaternion.identity);
        gasParticle.SetActive(false);
        playerSprite.color = Color.black;
        camShake.DoNoise(4, 4, 0.5f);
        dieSound.Play();

        yield return new WaitForSecondsRealtime(1f);

        transition.FadeOut("Lobby");

    }


    public void Flash()
    {
        if (currentFlashTime > 0)
        {
            playerSprite.material = flashMat;
            currentFlashTime -= Time.deltaTime;

           // gigaFlash.SetActive(true);

            for (int i = 0; i < hearts.Length; i++)
            {
                if (i < currentHealth)
                {
                    hearts[i].material = flashMat;
                }
              
            }

        }
        else
        {
            playerSprite.material = currentMat;
            //gigaFlash.SetActive(false);

            for (int i = 0; i < hearts.Length; i++)
            {
                if (i < currentHealth)
                {
                    hearts[i].material = currentMat;
                }
                
            }
        }
    }

    public void Stun(float stunTime)
    {
        currentStunTime = stunTime;
        _base.isStunned = true;
    }

    public void Bump(float force, Transform ObjectDir, float drag)
    {
        
        var forceDir = transform.position - ObjectDir.position;

        rb.AddForce(forceDir.normalized * force, ForceMode2D.Impulse);
        rb.drag = drag;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("BossBody"))
        {
            TakeDamange(1);

            Stun(0.3f);

            Bump(15, collision.transform, 5);

            _dash.stopDash();

        }

  
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("SlamObject"))
        {
            TakeDamange(1);

            Stun(0.5f);

            Bump(20, collision.transform, 10);

            _dash.stopDash();

        }
    }



}
