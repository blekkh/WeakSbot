using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimations : MonoBehaviour
{

    private PlayerBase playerBase;

    public float weaponAngle;
    public bool facingRight = true;
    public bool facingUp = false;
    public bool isMoving;
    

    private Animator anim;

    public ParticleSystemRenderer gasParticle;
    
    void Start()
    {
        playerBase = GetComponentInParent<PlayerBase>();
        anim = GetComponent<Animator>();
    }

    void FixedUpdate()
    {
    
            //check movement input
            isMoving = playerBase.isMoving;


            //check weapon Angle
            weaponAngle = playerBase.weaponAngle;

            if (weaponAngle < 90 && weaponAngle > -90)
                facingUp = true;
            else
                facingUp = false;

            if (weaponAngle >= 0)
                facingRight = true;
            else
                facingRight = false;

            // Flip Funktion based on Weapon Angle
            Flip();
       
    }

    private void Update()
    {
            // Update Animation Parameters
            if (playerBase.isDead == false)
            {
            anim.SetBool("facingUp", facingUp);
                anim.SetBool("isMoving", isMoving);
            }
    }

    public void Flip()
    {
        if (facingRight)
        {
            transform.localEulerAngles = new Vector3(0, 0, 0);
          
        }
        else
        {
            transform.localEulerAngles = new Vector3(0, 180, 0);
        }

    }
}
