using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerBase : MonoBehaviour
{

    [Header("Movement Stats")]
    public float speed;
    public Vector2 movementInput;
    public float moveAngle;
    public bool isMoving; // Based on Input
    public bool isDashing = false;
    private PlayerDash playerDash;

    [Header("Combat Stats")]
    public Transform weaponPivot;
    private bool isAiming; // Based on Input
    private Vector2 attackInputGamePad;
    public float weaponAngle;
    public bool isAttacking;
    public bool isStunned;

    [Header("Other")]
    public Camera mainCam;
    private Rigidbody2D rb;
    private PlayerInput playerInput;
    public bool isDead;
    private InGameCursor cursorScript;
    private Vector3 mousePos;
    public bool isUsing;
    private PlayerUpgrades playerUpgrades;
    public bool inDialogue;
    



    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerInput = GetComponent<PlayerInput>();
        playerDash = GetComponent<PlayerDash>();
        cursorScript = FindObjectOfType<InGameCursor>();
        playerUpgrades = FindObjectOfType<PlayerUpgrades>();

        if(playerUpgrades != null)
        switch (playerUpgrades.currentSpeedUpgrades)
        {
            case 0: speed *= 1;
                break;
            case 1:
                speed *= 1.1f;
                break;
            case 2:
                speed *=  1.15f;
                break;
            case 3:
                speed *=  1.2f;
                break;
            case 4:
                speed *=  1.25f;
                break;
            case 5:
                speed *=  1.3f;
                break;
            case 6:
                speed *=  1.35f;
                break;
            case 7:
                speed *=  1.4f;
                break;
            case 8:
                speed *=  1.45f;
                break;
            case 9:
                speed *=  1.5f;
                break;
            case 10:
                speed *=  1.55f;
                break;
        }

    }

    private void Update()
    {

        //Update Cursor Position
        if (playerInput.currentControlScheme == "Controller")
            cursorScript.runOnController(weaponAngle);

        if (playerInput.currentControlScheme == "KBM")
            cursorScript.runOnMouse();


    }


    private void FixedUpdate()
    {
        if (!isDead)
        {
            // Movement
            moveAngle = Mathf.Atan2(movementInput.x, movementInput.y) * Mathf.Rad2Deg;

            if (!isDashing && !isStunned && !inDialogue)
                rb.velocity = movementInput * speed;

            if (inDialogue)
                rb.velocity = new Vector2(0, 0);

            // Update Aim Angle for "KBM" Scheme
            if (playerInput.currentControlScheme == "KBM")
            {
                weaponAngle = DefineAimAngleKBM();
                cursorScript.runOnMouse();
            }

            // Update Aim Angle for "Controller" Scheme
            if (isAiming && playerInput.currentControlScheme == "Controller")
            {
                weaponAngle = DefineAimAngleController();
            }


            // Update WeaponPivot based on AimAngle
            weaponPivot.gameObject.transform.eulerAngles = new Vector3(weaponPivot.gameObject.transform.eulerAngles.x, weaponPivot.gameObject.transform.eulerAngles.y, -weaponAngle + 90);

        }
        else
        {
            rb.drag = 5;
        }

    }


    // Get Aim Angle "Controller" Scheme
    public float DefineAimAngleController()
    {
        //Check if aim Input is given -> if not use movement input
        return Mathf.Atan2(attackInputGamePad.x, attackInputGamePad.y) * Mathf.Rad2Deg;
    }

    // Get Aim Angle "KBM" Scheme
    public float DefineAimAngleKBM()
    {
        // Get Mouse Pos
        mousePos = mainCam.ScreenToWorldPoint(Mouse.current.position.ReadValue()) - transform.position;

        return Mathf.Atan2(mousePos.normalized.x, mousePos.normalized.y) * Mathf.Rad2Deg;
    }



    // Check Player Input
    public void OnMove(InputAction.CallbackContext context)
    {
        movementInput = context.ReadValue<Vector2>().normalized;

        if (context.started) isMoving = true;

        if (context.canceled) isMoving = false;

    }

    public void OnAimGamePad(InputAction.CallbackContext context)
    {

            attackInputGamePad = context.ReadValue<Vector2>().normalized;

 
        if (context.started) isAiming = true;

        if (context.canceled) isAiming = false;

    }


    public void OnAttack(InputAction.CallbackContext context)
    {
        if(!isDead)
            if (context.started) isAttacking = true;
        
        if (context.canceled) isAttacking = false;

        if (inDialogue)
        {
            if (context.started) FindObjectOfType<DialogueManager>().DisplayNextSenctence();
        }

    }

    public void OnDash(InputAction.CallbackContext context)
    {
        if (!isDead && movementInput != new Vector2(0,0))
            if (context.performed) playerDash.Dash();
        
      


        if (inDialogue)
        {
            if (context.started) FindObjectOfType<DialogueManager>().DisplayNextSenctence();
        }
    }

    public void onUse(InputAction.CallbackContext context)
    {
        if(!inDialogue)
        if (context.started) isUsing = true;

        if (context.canceled) isUsing = false;


        if (inDialogue)
        {
            if (context.started) FindObjectOfType<DialogueManager>().DisplayNextSenctence();
        }
    }
}
