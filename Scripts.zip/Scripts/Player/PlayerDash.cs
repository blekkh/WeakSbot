using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDash : MonoBehaviour
{

    private PlayerBase _base;
    private Rigidbody2D rb;

    public CameraShake camShake;

    public float dashForce;
    public float dashCooldown;
    public float dashDuration;
    private float currentDashDuration;
    private float currentDashCooldown;
    private Vector2 dashDir;
    public ParticleSystem dashParticle;
    public ParticleSystem gasParticle;

    public PlayerUpgrades playerUpgrades;

    public AudioSource dashSound;

    public bool stoppedDashing;

    void Start()
    {
        playerUpgrades = FindObjectOfType<PlayerUpgrades>();

        if (playerUpgrades != null)
            switch (playerUpgrades.currentDashUpgrades)
            {
                case 0:
                    dashDuration = 0.2f;
                    break;
                case 1:
                    dashDuration = 0.225f;
                    break;
                case 2:
                    dashDuration = 0.25f;
                    break;
                case 3:
                    dashDuration = 0.275f;
                    break;
                case 4:
                    dashDuration = 0.3f;
                    break;
                case 5:
                    dashDuration = 0.325f;
                    break;
                case 6:
                    dashDuration = 0.35f;
                    break;
                case 7:
                    dashDuration = 0.375f;
                    break;
                case 8:
                    dashDuration = 0.4f;
                    break;
                case 9:
                    dashDuration = 0.425f;
                    break;
                case 10:
                    dashDuration = 0.45f;
                    break;
            }


        _base = GetComponent<PlayerBase>();
        rb = GetComponent<Rigidbody2D>();

    }

    void Update()
    {
        dashDir = _base.movementInput;

        if(currentDashCooldown > 0)
        {
            currentDashCooldown -= Time.deltaTime;
        }

        if (currentDashDuration > 0)
        {
            currentDashDuration -= Time.deltaTime;
        }
        else
        {
            stopDash();
        }

    }

    public void stopDash()
    {

        _base.isDashing = false;

        rb.drag = 5;

        var emmisionOverTime = gasParticle.emission;
        emmisionOverTime.rateOverTime = 5;

    }

    public void Dash()
    {
        if(currentDashCooldown <= 0)
        {

            dashSound.Play();
            camShake.DoNoise(1.2f,1.2f,0.1f);
            dashParticle.Play();
            dashParticle.gameObject.transform.eulerAngles = new Vector3(dashParticle.gameObject.transform.eulerAngles.x, dashParticle.gameObject.transform.eulerAngles.y, -(Mathf.Atan2(_base.movementInput.normalized.x, _base.movementInput.normalized.y) * Mathf.Rad2Deg));
            _base.isDashing = true;
            rb.velocity = new Vector2(0, 0);
            rb.AddForce(dashDir * dashForce, ForceMode2D.Impulse);
            rb.drag = 0;
            currentDashCooldown = dashCooldown;
            currentDashDuration = dashDuration;
            var emmisionOverTime = gasParticle.emission;
            emmisionOverTime.rateOverTime = 50;
            
        }   
       
    }

}
