using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class newTransition : MonoBehaviour
{

    public float transitionSpeed;
    public SpriteRenderer sprite;

    private bool fadeOutTrigger;
    private bool fadeInTrigger;

    // Start is called before the first frame update
    void Start()
    {
        sprite = GetComponent<SpriteRenderer>();

        FadeIn();
    }

    // Update is called once per frame
    void Update()
    {
        if (fadeOutTrigger)
            transform.localScale += new Vector3(1f * Time.deltaTime * transitionSpeed, 1f * Time.deltaTime * transitionSpeed, 0);


        if(fadeInTrigger && transform.localScale.x >= 0)
            transform.localScale += new Vector3(-1f * Time.deltaTime * transitionSpeed / 2, -1f * Time.deltaTime * transitionSpeed / 2, 0);


        if(transform.localScale.x <= 0)
        {
            sprite.enabled = false;
        } else
        {
            sprite.enabled = true;
        }
    }


    public void FadeOut(string LoadScene)
    {
        StartCoroutine(FadeOutEnum(LoadScene));
    }

    public IEnumerator FadeOutEnum(string LoadScene)
    {
        fadeOutTrigger = true;
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene(LoadScene);
    }

    public void FadeIn()
    {
        fadeInTrigger = true;
        transform.localScale = new Vector3(50, 50, 0);
    }
   

}
