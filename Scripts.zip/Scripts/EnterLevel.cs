using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class EnterLevel : MonoBehaviour
{

    private Animator anim;
    private CameraShake camShake;
    public newTransition newTran;

    public AudioSource enterDoorSound;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        camShake = FindObjectOfType<CameraShake>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void onEnterFight()
    {
        StartCoroutine(onEnterFightEnum());
    }

    public IEnumerator onEnterFightEnum()
    {
        enterDoorSound.Play();


        camShake.DoNoise(3, 3, 4);
        anim.SetTrigger("Open");
        yield return new WaitForSecondsRealtime(2f);
        newTran.FadeOut("SampleScene");

    }
}
