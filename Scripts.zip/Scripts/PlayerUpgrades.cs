using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;


public class PlayerUpgrades : MonoBehaviour
{

    public int currentHealthUpgrades;
    public int currentSpeedUpgrades;
    public int currentDashUpgrades;


    private SelectLevel selectLevel;

    public int maxPoints;
    public int currentPoints;

    public TMP_Text healthText;
    public TMP_Text speedText;
    public TMP_Text dashText;
    public TMP_Text currentPointsText;

    private PlayerDash _dash;
    private PlayerBase _base;



    // Start is called before the first frame update
    void Start()
    {

        selectLevel = GetComponent<SelectLevel>();
    }

    // Update is called once per frame
    void Update()
    {
        _dash = FindObjectOfType<PlayerDash>();
        _base = FindObjectOfType<PlayerBase>();

        var currenScene = SceneManager.GetActiveScene();

        if (currenScene.name == "Lobby")
        {
            healthText = GameObject.Find("HealthPoints").GetComponent<TMP_Text>();
 
            speedText = GameObject.Find("SpeedPoints").GetComponent<TMP_Text>();
       
            dashText = GameObject.Find("DashPoints").GetComponent<TMP_Text>();
     
            currentPointsText = GameObject.Find("UpgradePoints").GetComponent<TMP_Text>();
        }


        maxPoints = selectLevel.unlockedlevels;

        currentPoints = maxPoints - (currentDashUpgrades + currentHealthUpgrades + currentSpeedUpgrades);

   
            healthText.text = currentHealthUpgrades.ToString();
    
            speedText.text = currentSpeedUpgrades.ToString();
      
            dashText.text = currentDashUpgrades.ToString();
      
            currentPointsText.text = currentPoints.ToString();

    }


    public void onUpgradeHealth()
    {


        if (currentPoints > 0)
        {

            currentPoints--;

            currentHealthUpgrades++;

        }
    }

    public void onUpgradeSpeed()
    {
        if (currentPoints > 0)
        {

            currentPoints--;

            currentSpeedUpgrades++;

            switch (currentSpeedUpgrades)
            {
                case 0:
                    _base.speed = 1 * 4;
                    break;
                case 1:
                    _base.speed = 1.1f * 4;
                    break;
                case 2:
                    _base.speed = 1.15f * 4;
                    break;
                case 3:
                    _base.speed = 1.2f * 4;
                    break;
                case 4:
                    _base.speed = 1.25f * 4;
                    break;
                case 5:
                    _base.speed = 1.3f * 4;
                    break;
                case 6:
                    _base.speed = 1.35f * 4;
                    break;
                case 7:
                    _base.speed = 1.4f * 4;
                    break;
                case 8:
                    _base.speed = 1.45f * 4;
                    break;
                case 9:
                    _base.speed = 1.5f *4;
                    break;
                case 10:
                    _base.speed = 1.55f *4;
                    break;
            }

        }
    }

    public void onUpgradeDash()
    {
        if (currentPoints > 0)
        {

            currentPoints--;

            currentDashUpgrades++;

            switch (currentDashUpgrades)
            {
                case 0:
                    _dash.dashDuration = 0.2f;
                    break;
                case 1:
                    _dash.dashDuration = 0.21f;
                    break;
                case 2:
                    _dash.dashDuration = 0.22f;
                    break;
                case 3:
                    _dash.dashDuration = 0.23f;
                    break;
                case 4:
                    _dash.dashDuration = 0.24f;
                    break;
                case 5:
                    _dash.dashDuration = 0.25f;
                    break;
                case 6:
                    _dash.dashDuration = 0.26f;
                    break;
                case 7:
                    _dash.dashDuration = 0.27f;
                    break;
                case 8:
                    _dash.dashDuration = 0.28f;
                    break;
                case 9:
                    _dash.dashDuration = 0.29f;
                    break;
                case 10:
                    _dash.dashDuration = 0.3f;
                    break;
            }

        }
    }

    public void onUpgradeReset()
    {

        currentHealthUpgrades = 0;
        currentSpeedUpgrades = 0;
        currentDashUpgrades = 0;

        currentPoints = maxPoints;

        _base.speed = 4;
        _dash.dashDuration = 0.2f;

}

}
