using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class SelectUse : MonoBehaviour
{

    private SpriteRenderer spriteRendere;
    public Sprite selectSprite;
    public Sprite usedSprite;
    private Sprite currentSprite;
    public float usedCooldown;
    private float currentUsedCooldown;

    public bool selected;
    public bool canSelect;

    public PlayerBase _playerBase;

    public string objectTag;

    public bool used;

    private CameraShake camShake;

    public AudioSource buttonPress;

    // Start is called before the first frame update
    void Start()
    {
        spriteRendere = GetComponent<SpriteRenderer>();
        currentSprite = spriteRendere.sprite;
        _playerBase = FindObjectOfType<PlayerBase>();

        objectTag = gameObject.tag;

        camShake = FindObjectOfType<CameraShake>();

    }

    // Update is called once per frame
    void Update()
    {

        if (selected)
        {
            spriteRendere.sprite = selectSprite;
        } else
        {
            spriteRendere.sprite = currentSprite;
        }


        if(currentUsedCooldown > 0)
        {
            spriteRendere.sprite = usedSprite;
            currentUsedCooldown -= Time.deltaTime;
            canSelect = false;
        } else
        {
            canSelect = true;
        }

        used = _playerBase.isUsing;

        if(used && canSelect && selected)
        {
            onSelect();
        }


    }


    private void OnTriggerEnter2D(Collider2D collision)
    {


        if (collision.CompareTag("Player"))
        {
            if (canSelect)
            {
                selected = true;
            }
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            selected = false;

        }
    }


    public void onSelect()
    {

       
        currentUsedCooldown = usedCooldown;

        if (objectTag == "LeaveFight")
        {
            buttonPress.Play();
            GetComponent<backToLobbyButton>().OnLeave();
        }

        if (objectTag == "IncreaseLVL")
        {
            FindObjectOfType<SelectLevel>().IncreaseLVL();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }

        if (objectTag == "DecreaseLVL")
        {
            FindObjectOfType<SelectLevel>().DecreaseLVL();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }

        if (objectTag == "EnterGame")
        {
            GetComponent<EnterLevel>().onEnterFight();
        }

        if (objectTag == "UpgradeHealth")
        {
            FindObjectOfType<PlayerUpgrades>().onUpgradeHealth();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }

        if (objectTag == "UpgradeSpeed")
        {
            FindObjectOfType<PlayerUpgrades>().onUpgradeSpeed();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }

        if (objectTag == "UpgradeDash")
        {
            FindObjectOfType<PlayerUpgrades>().onUpgradeDash();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }


        if (objectTag == "ResetUpgrades")
        {
            FindObjectOfType<PlayerUpgrades>().onUpgradeReset();
            buttonPress.Play();
            camShake.DoNoise(0.5f, 0.5f, 0.3f);
        }

        if(objectTag == "Dialogue")
        {
            GetComponent<DialogueTrigger>().TriggerDialogue();
        }

        if(objectTag == "SecretRoom")
        {

            GetComponent<DialogueTrigger>().TriggerDialogue();
            
        }

        if (objectTag == "Alexa")
        {
            GetComponent<DialogueTrigger>().TriggerDialogue();
        }





    }





}
