using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SelectLevel : MonoBehaviour
{

    public int levelSelected;


    public int unlockedlevels = 3;

    public int newUnlockedLevels;

    private bool isUpdating;

    private PlayerUpgrades playerUp;

    public AudioSource newLightSound;


    private CameraShake camShake;

    private void Start()
    {
        playerUp = GetComponent<PlayerUpgrades>();
    }

    private void Update()
    {
        camShake = FindObjectOfType<CameraShake>();
    

        Scene currentScene = SceneManager.GetActiveScene();

         if(newUnlockedLevels != unlockedlevels && currentScene.name == "Lobby" && !isUpdating)
        {
        
            StartCoroutine(updateLevels());
            isUpdating = true;

        }
    }


    public void IncreaseLVL()
    {

        if(levelSelected < unlockedlevels && !isUpdating)
        {
            levelSelected++;
        }

    }

    public void DecreaseLVL()
    {
        if (levelSelected > 1 && !isUpdating)
        {
            levelSelected--;
        }
    }

    public IEnumerator updateLevels()
    {
        yield return new WaitForSecondsRealtime(2f);
        camShake.DoNoise(2, 2, 2);
        yield return new WaitForSecondsRealtime(1f);
        unlockedlevels = newUnlockedLevels;
        levelSelected = newUnlockedLevels;
        isUpdating = false;

    }
}
