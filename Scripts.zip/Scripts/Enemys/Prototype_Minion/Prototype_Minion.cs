using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_Minion : MonoBehaviour
{

    public int maxHealth;
    private int currentHealth;

    public float flashTime;
    private float currentFlashTime;

    public float stunTime;
    private float currentStunTime;

    public int damage;
    public int speed;
    public float visionRange;
    private Vector2 playerDir;

    public bool isStunned;

    public float invicibleTime;
    private float currentInvTime;


    private Transform playerPos;
    private float playerDistance;

    public SpriteRenderer sprite;
    public Material flashMat;
    private Material currentMat;

    private CircleCollider2D collider2d;

    public GameObject shadown;

    private bool isDead;

    public GameObject StrikeParticle;
    public GameObject SlashParticle;
    public GameObject burnParticle;

    private CameraShake camShake;

    private GameObject newBurnPar;

    public Animator anim;

    Rigidbody2D rb;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        currentHealth = maxHealth;
        currentMat = sprite.material;
        collider2d = GetComponent<CircleCollider2D>();
        camShake = FindObjectOfType<CameraShake>();
    }

    private void Update()
    {
        if (!isDead)
        {
            Flash();

            if (currentStunTime > 0)
            {
                currentStunTime -= Time.deltaTime;
            }
            else
            {
                isStunned = false;
                rb.drag = 0;
            }

            if (currentInvTime > 0)
            {
                currentInvTime -= Time.deltaTime;
            }

        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if(newBurnPar != null)
            newBurnPar.transform.position = transform.position;

        if (!isDead)
        {
            playerPos = GameObject.FindGameObjectWithTag("Player").transform;

            playerDistance = Vector2.Distance(transform.position, playerPos.position);

            playerDir = playerPos.position - transform.position;

            if (playerDistance <= visionRange && !isStunned)
            {
                rb.velocity = playerDir.normalized * speed;
                anim.SetFloat("VelX", rb.velocity.x);
                anim.SetFloat("VelY", rb.velocity.y);

            }
            else if (playerDistance > visionRange && !isStunned)
                rb.velocity = new Vector2(0, 0);
        }
    }


    public void TakeDamage(int damageAmmount)
    {
        if (currentInvTime <= 0)
        {
            currentHealth -= damageAmmount;

            if (currentHealth <= 0)
            {

                Instantiate(StrikeParticle, transform.position, Quaternion.identity);
                Instantiate(SlashParticle, transform.position, Quaternion.identity);

                Destroy(gameObject);

            }


            anim.SetTrigger("Hit");

            currentFlashTime = flashTime;

            Stun(stunTime);

            Bump(5, playerPos.transform, 5);

            currentInvTime = invicibleTime;
            
            

        }
    }



    public void Flash()
    {
        if (currentFlashTime > 0)
        {
            sprite.material = flashMat;
            currentFlashTime -= Time.deltaTime;
        }
        else
        {
            sprite.material = currentMat;
        }
    }

    public void Stun(float stunTime)
    {
        currentStunTime = stunTime;
        isStunned = true;
    }

    public void Bump(float force, Transform ObjectDir, float drag)
    {

        var forceDir = transform.position - ObjectDir.position;

        rb.AddForce(forceDir.normalized * force, ForceMode2D.Impulse);
        rb.drag = drag;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && !isDead)
        {
            collision.GetComponent<PlayerHealth>().TakeDamange(damage);
            this.TakeDamage(100);
            Bump(5, collision.transform, 5);
        }
    }
}
