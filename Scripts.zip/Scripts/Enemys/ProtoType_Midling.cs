using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProtoType_Midling : MonoBehaviour
{
    public int maxHealth;
    private int currentHealth;

    public float flashTime;
    private float currentFlashTime;

    public float stunTime;
    private float currentStunTime;

    public int damage;
    public int speed;
    public float visionRange;
    public float visionMinRange;
    private Vector2 playerDir;

    public bool isStunned;

    public float invicibleTime;
    private float currentInvTime;


    private Transform playerPos;
    private float playerDistance;

    public SpriteRenderer sprite;
    public Material flashMat;
    private Material currentMat;

    public GameObject shadown;

    private bool isDead;

    public GameObject StrikeParticle;
    public GameObject SlashParticle;

    public GameObject shootParticle;

    private CameraShake camShake;

    public Transform shootBase;
    public Transform shootPos;
    public GameObject bulletPref;
    private float shootAngle;
    public float shootCooldown;
    private float currenShootCooldown;

    public int bulletCount; 
    public float bulletSpeed; 
    public float spreadIncrease; 
    public float sinCurveForce; 
    public float sinCurveValue; 
    public bool addForce;
    private float anticipationTime = 0.15f;


    private bool isAttacking;



    public Animator anim;

    Rigidbody2D rb;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        currentHealth = maxHealth;
        currentMat = sprite.material;
        camShake = FindObjectOfType<CameraShake>();
        currenShootCooldown = shootCooldown;
    }

    private void Update()
    {
        if (!isDead)
        {
            Flash();

            if (currentStunTime > 0)
            {
                currentStunTime -= Time.deltaTime;
            }
            else
            {
                isStunned = false;
                rb.drag = 0;
            }

            if (currentInvTime > 0)
            {
                currentInvTime -= Time.deltaTime;
            }

            if(!isStunned)
                if(currenShootCooldown > 0)
                {
                    currenShootCooldown -= Time.deltaTime;
                } else
                {
               
                     StartCoroutine(Attack(bulletCount, bulletSpeed, spreadIncrease, sinCurveForce, sinCurveValue, addForce));
                }

        }
    }

    // Update is called once per frame
    void FixedUpdate()
    {

        if (!isDead)
        {
            playerPos = GameObject.FindGameObjectWithTag("Player").transform;

            playerDistance = Vector2.Distance(transform.position, playerPos.position);

            playerDir = playerPos.position - transform.position;

            if (playerDistance < visionRange && !isStunned && playerDistance > visionMinRange && !isAttacking)
            {
                rb.velocity = playerDir.normalized * speed;
                anim.SetFloat("VelX", rb.velocity.x);
                anim.SetFloat("VelY", rb.velocity.y);

            } else
            {
                rb.velocity = playerDir.normalized * 0;
                anim.SetFloat("VelX", playerPos.transform.position.x - transform.position.x);
                anim.SetFloat("VelY", playerPos.transform.position.y - transform.position.y);
            }

  
        }
    }


    public void TakeDamage(int damageAmmount)
    {
        if (currentInvTime <= 0)
        {
            currentHealth -= damageAmmount;

            if (currentHealth <= 0)
            {

                Instantiate(StrikeParticle, transform.position, Quaternion.identity);
                Instantiate(SlashParticle, transform.position, Quaternion.identity);

                Destroy(gameObject);

            }


            anim.SetTrigger("Hit");

            currentFlashTime = flashTime;

            Stun(stunTime);

            Bump(5, playerPos.transform, 5);

            currentInvTime = invicibleTime;



        }
    }

    public IEnumerator Attack(int bulletCount, float bulletSpeed, float spreadIncrease, float sinCurveForce, float sinCurveValue, bool addForce)
    {

        anim.SetTrigger("Attack");

        currenShootCooldown = shootCooldown;

        isAttacking = false;

        yield return new WaitForSecondsRealtime(anticipationTime);

        camShake.DoNoise(1f, 1f, 0.3f);
        shootAngle = 0;

        

        for (int j = 0; j < bulletCount; j++)
            {
                GameObject bulletClone = Instantiate(bulletPref, shootPos.transform.position, Quaternion.identity);

                Rigidbody2D bulletRB = bulletClone.GetComponent<Rigidbody2D>();

                bulletClone.GetComponent<bulletScript>().addForce = addForce;
                bulletClone.GetComponent<bulletScript>().force = sinCurveForce;
                bulletClone.GetComponent<bulletScript>().addAngleValue = sinCurveValue;

                shootBase.transform.eulerAngles = new Vector3(0, 0, shootAngle);
                bulletClone.transform.eulerAngles = new Vector3(0, 0, shootAngle);

                shootAngle += spreadIncrease;

                bulletRB.AddForce(shootPos.transform.right * bulletSpeed, ForceMode2D.Impulse);

                var newPart = Instantiate(shootParticle, shootPos.transform.position, Quaternion.identity);

                newPart.transform.eulerAngles = new Vector3(0, 0, shootPos.transform.eulerAngles.z  - 90);

                newPart.GetComponent<SelfDestruct>().time = 3;
           


        }

        isAttacking = false;

    }



    public void Flash()
    {
        if (currentFlashTime > 0)
        {
            sprite.material = flashMat;
            currentFlashTime -= Time.deltaTime;
        }
        else
        {
            sprite.material = currentMat;
        }
    }

    public void Stun(float stunTime)
    {
        currentStunTime = stunTime;
        isStunned = true;
    }

    public void Bump(float force, Transform ObjectDir, float drag)
    {

        var forceDir = transform.position - ObjectDir.position;

        rb.AddForce(forceDir.normalized * force, ForceMode2D.Impulse);
        rb.drag = drag;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player") && !isDead)
        {
            collision.GetComponent<PlayerHealth>().TakeDamange(damage);
            this.TakeDamage(1);
            Bump(5, collision.transform, 5);
        }
    }
}
