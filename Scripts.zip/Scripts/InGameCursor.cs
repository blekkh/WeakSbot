using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class InGameCursor : MonoBehaviour
{


    public Transform controllerCursorPos;
    public Transform controllerCursorHolder;

    public Camera mainCam;

    Vector3 mousePos;


    private void Update()
    {
        mousePos = mainCam.ScreenToWorldPoint(Mouse.current.position.ReadValue());
        Cursor.visible = false;
    }

    public void runOnMouse()
    {

        transform.position = new Vector3(mousePos.x, mousePos.y, 0);
    }

    public void runOnController(float angle)
    {
        transform.position = controllerCursorPos.position;
        controllerCursorHolder.gameObject.transform.eulerAngles = new Vector3(controllerCursorHolder.gameObject.transform.eulerAngles.x, controllerCursorHolder.gameObject.transform.eulerAngles.y, -angle + 90);
    }
}
