using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThrowTrigger : MonoBehaviour
{

    public bool isThrowing;

    private PlayerBase playerBase;

    public float throwForce;
    public Vector2 throwAngle;
    public 

    // Start is called before the first frame update
    void Start()
    {
        playerBase = GetComponentInParent<PlayerBase>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
