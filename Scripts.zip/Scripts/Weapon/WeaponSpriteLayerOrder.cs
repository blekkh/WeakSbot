using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponSpriteLayerOrder : MonoBehaviour
{

    public PlayerAnimations playerAnims;
    private SpriteRenderer spriteRenderer;

    public float topWeaponPos;
    public float bottomWeaponPos;



    void Start()
    {
        spriteRenderer = GetComponentInChildren<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {

        //Change position that pivot point of weapon sprite is higher than player sprite pivot 

        if (!playerAnims.facingRight && playerAnims.facingUp) transform.localPosition =  new Vector3(transform.localPosition.x, topWeaponPos, transform.localPosition.z);
        if (playerAnims.facingRight && !playerAnims.facingUp) transform.localPosition = new Vector3(transform.localPosition.x, topWeaponPos, transform.localPosition.z);
        if (playerAnims.facingRight && playerAnims.facingUp) transform.localPosition = new Vector3(transform.localPosition.x, bottomWeaponPos, transform.localPosition.z);
        if (!playerAnims.facingRight && !playerAnims.facingUp) transform.localPosition = new Vector3(transform.localPosition.x, bottomWeaponPos, transform.localPosition.z);

        if (playerAnims.facingRight) transform.localScale = new Vector3(1,1,1);
        if (!playerAnims.facingRight) transform.localScale = new Vector3(1, -1, 1);

    }
}
