using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponTrigger : MonoBehaviour
{

    [Header("Weapon Stats")]
    public float attackCooldown;
    private float currentAttackCooldown;
    private bool attackReloaded;
    public Transform shootPos;
    public float weaponKnockback;
    public float weaponKnockbackSpeed;

    [Header("Bullet Stats")]
    public GameObject bulletPrefab;
    public float bulletSpeed;
    public float bulletSpeedIncrease; //When Player is moving forwards while shootings forwards the bullet should be faster then the player
    public float bulletLifeTime;
    public float bulletDamage;

    [Header("Other")]
    public GameObject weaponSprite;
    public ParticleSystem shootingParticle1;
    private CameraShake cameraShake;
    public float camShakeAmp;
    public float camShakeFreq;
    public float camShakeElapTime;

    public AudioSource shootSound;

    [Header("Inheritet")]
    public bool isAttacking;
    private PlayerBase playerBase;


    private void Start()
    {
        playerBase = GetComponentInParent<PlayerBase>();
        cameraShake = FindObjectOfType<CameraShake>();
    }


    private void Update()
    {
        isAttacking = playerBase.isAttacking;
        AttackManagement();

        if (weaponSprite.transform.localPosition.x < 0) weaponSprite.transform.localPosition = Vector2.MoveTowards(weaponSprite.transform.localPosition, new Vector2(0, 0), weaponKnockbackSpeed * Time.deltaTime);


    }



    // Managing Attack 
    public void AttackManagement()
    {
        if (isAttacking && currentAttackCooldown <= 0)
        {
            attackReloaded = false;
            currentAttackCooldown = attackCooldown;

            var newBullet = Instantiate(bulletPrefab, shootPos.position, Quaternion.identity);
            var newBulletRb = newBullet.GetComponent<Rigidbody2D>();
            var newBulletBehaviour = newBullet.GetComponent<BulletBehaviour>();
            newBullet.transform.eulerAngles = new Vector3(transform.eulerAngles.x, transform.eulerAngles.y, transform.eulerAngles.z - 90);
            newBulletBehaviour.lifeTime = bulletLifeTime;

            newBulletRb.AddForce(transform.right * bulletSpeed, ForceMode2D.Impulse);

            weaponSprite.transform.localPosition = new Vector3(-weaponKnockback,0,0);

            shootingParticle1.Play();

            cameraShake.DoNoise(camShakeAmp, camShakeFreq, camShakeElapTime);
            
            shootSound.Play();



        }

        if (currentAttackCooldown > 0) currentAttackCooldown -= Time.deltaTime;

        if (currentAttackCooldown < 0 && !attackReloaded)
        {         
            attackReloaded = true;
          
        }
    }
}
