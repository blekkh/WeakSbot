using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehaviour : MonoBehaviour
{

    public float lifeTime;
    private float currentLifeTime;


    // Start is called before the first frame update
    void Start()
    {

        currentLifeTime = lifeTime;
        
    }

    // Update is called once per frame
    void Update()
    {

        if (currentLifeTime > 0) currentLifeTime -= Time.deltaTime;
        if (currentLifeTime <= 0) Destroy(gameObject);

    }

    //On Hit something indesctructable

    public GameObject particle;
    public Transform particleSpawnPoint;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Boss_Fakehitbox"))
        {
            Instantiate(particle, particleSpawnPoint.position, particleSpawnPoint.rotation);
            Destroy(gameObject);
        }

        if (collision.CompareTag("BossHitBox"))
        {
            collision.GetComponentInParent<ProtoType_Health>().TakeDamange(10);
        }

        if (collision.CompareTag("BossMinion"))
        {
            if(collision.GetComponent<Prototype_Minion>() != null)
            collision.GetComponent<Prototype_Minion>().TakeDamage(1);

            if (collision.GetComponent<ProtoType_Midling>() != null)
                collision.GetComponent<ProtoType_Midling>().TakeDamage(2);
        }

    }


}
