using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class selectLight : MonoBehaviour
{
    public int levelNumber;

    private Light2D lightComponent;

    private SelectLevel levelSelect;

    // Start is called before the first frame update
    void Start()
    {
        lightComponent = GetComponent<Light2D>();
        levelSelect = FindObjectOfType<SelectLevel>();
    }

    // Update is called once per frame
    void Update()
    {
        
        if(levelNumber <= levelSelect.unlockedlevels)
        {
            lightComponent.enabled = true;

            if(levelNumber == levelSelect.levelSelected)
            {
                lightComponent.intensity = 2;
            } else
            {
                lightComponent.intensity = 0.5f;
            }
        } else
        {
            lightComponent.enabled = false;
        }

    }
}
