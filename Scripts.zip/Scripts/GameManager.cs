using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    public int bossDifficulty;
    public GameObject bossGameObject;

    public newTransition transition;




    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(startFight());
    }

    // Update is called once per frame
    void Update()
    {




    }

    public IEnumerator startFight()
    {
      
        yield return new WaitForSecondsRealtime(2f);
        bossGameObject.SetActive(true);
    }
}
