using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_Slam : StateMachineBehaviour
{

    public Vector2 slamRadius;

    private Prototype_Base _Base;

    public bool canGetDamag;

    private GameObject slamObject;


    public float attackAnticipation = 0.75f;
    private float currentAntiTime;

    private bool hasSlamed;





    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        _Base = animator.GetComponent<Prototype_Base>();
        getFurthestHitBoxForSlam();
        _Base.canGetDamage = canGetDamag;

        slamObject = _Base.slamHitBox;

        slamObject.transform.localScale = slamRadius;

        animator.SetFloat("VerticalPlayerPos", -1);
        animator.SetFloat("HorizontalPlayerPos", 0);

        getFurthestHitBoxForSlam();

        currentAntiTime = attackAnticipation;
        hasSlamed = false;



    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
        if(currentAntiTime > 0)
        {
            currentAntiTime -= Time.deltaTime;
        } else
        {
            if (!hasSlamed)
            {
                hasSlamed = true;
                _Base.StartCoroutine(_Base.SlamAttack());
            }
        }

    }

    public void getFurthestHitBoxForSlam()
    {
        GameObject tMax = null;
        float maxDist = 0;
        Vector3 currentPos = new Vector3(0, -2, 0);
        foreach (GameObject t in _Base.hitBoxes)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist > maxDist)
            {
                tMax = t;
                maxDist = dist;
            }
        }

        _Base.furthestHitBox = tMax;

        for (int i = 0; i < _Base.hitBoxes.Length; i++)
        {
            if (_Base.hitBoxes[i] == tMax)
                _Base.hitBoxes[i].SetActive(true);
            else
                _Base.hitBoxes[i].SetActive(false);
        }


    }


    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
