using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_SearchPlayer : StateMachineBehaviour
{

    private Transform player;
    private Vector2 playerPos;
    private Vector2 playerDir;

    private Prototype_Base _Base;


    public float searchTime = 3f;
    private float currentSearchTime;

    public bool canGetDamage;

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        player = FindObjectOfType<PlayerBase>().transform;
        currentSearchTime = searchTime;
        _Base = animator.GetComponent<Prototype_Base>();
        _Base.finishedBurstFire = false;

        _Base.canGetDamage = canGetDamage;
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (currentSearchTime > 0)
        {
            _Base.getNearestShootingPoint();
            playerDir = _Base.shootPos.position -_Base.turretMittlePoint.position;
            playerDir = playerDir.normalized;


            animator.SetFloat("VerticalPlayerPos", playerDir.y);
            animator.SetFloat("HorizontalPlayerPos", playerDir.x);


            currentSearchTime -= Time.deltaTime;

            _Base.getFurthestHitBox();

        }

        if(currentSearchTime <= 0)
        {
            animator.SetTrigger("Attack");
        }

    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
