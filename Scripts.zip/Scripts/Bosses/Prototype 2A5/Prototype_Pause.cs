using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_Pause : StateMachineBehaviour
{

    public float PauseTime = 2;
    private float currentPauseTime;




    public bool canGetDamage;

    private Prototype_Base _Base;


    public string[] possibleStates;
    public string[] currentPossibleStates;

    public int nextState;
    private bool hasChosenState;
    private int usedStates;
    public int lastState;
    

    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        _Base = animator.GetComponent<Prototype_Base>();

        currentPauseTime = PauseTime;

        _Base.canGetDamage = canGetDamage;

 
        hasChosenState = false;

        lastState = nextState;

        nextState = Random.Range(0, currentPossibleStates.Length);

    
    }


    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        if (!hasChosenState)
        {

            if (currentPossibleStates[nextState] != null )
            {

                if (lastState != nextState)
                {
                    usedStates++;
                    hasChosenState = true;
                    currentPossibleStates[nextState] = null;
                    animator.SetInteger("NextState", nextState);

                } else
                {
                    nextState = Random.Range(0, currentPossibleStates.Length);
                }

            }
            else
            {
                nextState = Random.Range(0, currentPossibleStates.Length);
            }


            if (usedStates == currentPossibleStates.Length)
            {
                for (int i = 0; i < currentPossibleStates.Length; i++)
                    currentPossibleStates[i] = possibleStates[i];

                usedStates = 0;
            }
        }



            if (currentPauseTime > 0)
            {
                currentPauseTime -= Time.deltaTime;
            }
            else if (currentPauseTime <= 0)
            {
                if(hasChosenState)
                animator.SetTrigger("ChangeState");
            }
     
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
       
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
