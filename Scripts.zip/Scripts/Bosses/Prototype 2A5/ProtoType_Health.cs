using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ProtoType_Health : MonoBehaviour
{
    public float maxHealth;
    private float currentHealth;

    public Material hitMaterial;
    private Material currentMat;

    public float flashTime;
    private float currentFlashTime;

    private CameraShake camShake;

    public Slider healthSlider;
    public Image sliderFill;
    public Material hitSliderMat;
    

    private Animator anim;

    private bool hasSetMaxHealth;
    public ParticleSystem boldParticle;
    public ParticleSystem hitParticle;

    private Prototype_Base _Base;

    public ParticleSystem explosion1;
    public ParticleSystem explosion2;
    public ParticleSystem explosion3;
    public ParticleSystem burnParticle;

    public bool hasUnlockedLevel;

    public GameObject bigLaser;

    private bool isDead;

    public GameObject deathTrans;

    public bool canGetDamage;

    public AudioSource bossHit;
    public AudioSource bossDie;
   






    public CapsuleCollider2D[] colliders;

    private SelectLevel levelSelect;




    // Start is called before the first frame update
    void Start()
    {
      
        currentMat = GetComponent<SpriteRenderer>().material;
        camShake = FindObjectOfType<CameraShake>();
        anim = GetComponent<Animator>();
        _Base = GetComponent<Prototype_Base>();

        

    }

    // Update is called once per frame
    void Update()
    {

        levelSelect = FindObjectOfType<SelectLevel>();

        Flash();

        if(hasSetMaxHealth)
        anim.SetFloat("Health", currentHealth);

        if (isDead && deathTrans.activeSelf == true)
        {
            var sprite = deathTrans.GetComponent<SpriteRenderer>().color;
            sprite.a += Time.deltaTime;
        }
    }


    public void TakeDamange(float healthAmmount)
    {
       
        if (isDead == false)
        {
           
            if (canGetDamage)
            {
                currentHealth -= healthAmmount;

                currentFlashTime = flashTime;

                camShake.DoNoise(1, 1, 0.2f);

                healthSlider.value -= healthAmmount;

                bossHit.Play();

                GameObject newPar = Instantiate(boldParticle.gameObject, transform.position, Quaternion.identity);
                newPar.GetComponent<ParticleSystem>().Play();
                newPar.GetComponent<SelfDestruct>().time = 2;

                GameObject newPar2 = Instantiate(hitParticle.gameObject, _Base.furthestHitBox.transform.position, _Base.furthestHitBox.transform.rotation);
                newPar2.GetComponent<ParticleSystem>().Play();
                newPar2.GetComponent<SelfDestruct>().time = 2;

                if (currentHealth <= 0)
                {
                    StartCoroutine(OnDeath());
                    isDead = true;

                    bossDie.Play();

                    if(_Base.chosenDifficulty + 2 > levelSelect.newUnlockedLevels)
                        levelSelect.newUnlockedLevels = _Base.chosenDifficulty + 2;

                }
            }
        }

    }

    public IEnumerator OnDeath()
    {

        for (int i = 0; i < colliders.Length; i++)
        {
            colliders[i].enabled = false;
        }

        deathTrans.SetActive(true);
        for (int j = 0; j < 4; j++)
        {
            Instantiate(explosion3, transform.position, Quaternion.identity);
            Instantiate(burnParticle, transform.position, Quaternion.identity);

            _Base.canGetDamage = false;

            var allMinion = FindObjectsOfType<Prototype_Minion>();
            var allMidling = FindObjectsOfType<ProtoType_Midling>();

            if (allMidling.Length > 0)
                for (int i = 0; i < allMidling.Length; i++)
                {
                    allMidling[i].TakeDamage(100);
                }

            if (allMinion.Length > 0)
                for (int i = 0; i < allMinion.Length; i++)
                {
                    allMinion[i].TakeDamage(100);
                }

            Instantiate(explosion2, transform.position, Quaternion.identity);
            Instantiate(explosion1, transform.position, Quaternion.identity);
            camShake.DoNoise(4, 4, 0.5f);

            yield return new WaitForSecondsRealtime(0.7f);
        }
        yield return new WaitForSecondsRealtime(2f);
        SceneManager.LoadScene("Lobby");
        

    }

    public void SetMaxHealth(float healthAmmount)
    {

        maxHealth = healthAmmount;
        currentHealth = maxHealth;
        healthSlider.maxValue = maxHealth;
        healthSlider.value = maxHealth;

        var healthRectTransform = healthSlider.GetComponent<RectTransform>();
        healthRectTransform.sizeDelta = new Vector2(maxHealth / 2, 27.4f);

        hasSetMaxHealth = true;
    }

    


    public void Flash()
    {
        if (currentFlashTime > 0)
        {
            GetComponent<SpriteRenderer>().material = hitMaterial;
            currentFlashTime -= Time.deltaTime;
            sliderFill.material = hitSliderMat;
        }
        else
        {
            GetComponent<SpriteRenderer>().material = currentMat;
            sliderFill.material = currentMat;
        }
    }
}
