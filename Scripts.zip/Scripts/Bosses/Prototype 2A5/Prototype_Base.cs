using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_Base : MonoBehaviour
{

    public Transform[] shootPositions;
    public Transform shootPos;
    public Transform turretMittlePoint;

    private PlayerBase playerBase;

    public GameObject bulletPref;

    public bool finishedBurstFire;

    public GameObject[] hitBoxes;
    public GameObject furthestHitBox;

    public bool canGetDamage;


    public int chosenDifficulty;
    public int rageCount;

    private CameraShake camShake;

    public Transform laserBase;
    public Transform laserStartPoint;
    private ProtoType_Health _health;

    private GameManager gameManager;


    public GameObject slamHitBox;


    private Animator anim;

    [Header("Visual and Sound Effects")]
    public ParticleSystem loadUpParticleSystem;
    public ParticleSystem loadUpParticleSystem2;
    public GameObject shootParticle;
    public ParticleSystem StompPar1;
    public ParticleSystem StompPar2;
    public GameObject burnParticle;
    public ParticleSystem laserPar1;
    public ParticleSystem laserPar2;
    public ParticleSystem bigLoadUp1;
    public ParticleSystem bigLoadUp2;
    public ParticleSystem laserBeamShootPar;
    public ParticleSystem slamPart1;
    public ParticleSystem slamPart2;
    public ParticleSystem slamPart3;

    public AudioSource bossshot;

    private SelectLevel selectLeveL;

    public AudioSource bossSlam;
    public AudioSource spawnMinionSound;


    private void Start()
    {
        playerBase = FindObjectOfType<PlayerBase>();
        camShake = FindObjectOfType<CameraShake>();
        _health = GetComponent<ProtoType_Health>();
        gameManager = FindObjectOfType<GameManager>();

        if(gameManager != null)
        chosenDifficulty = gameManager.bossDifficulty;

        anim = GetComponent<Animator>();

        selectLeveL = FindObjectOfType<SelectLevel>();

        if(selectLeveL != null)
        chosenDifficulty = selectLeveL.levelSelected - 1;


        
    }

    private void Update()
    {

        _health.canGetDamage = canGetDamage;
        if (!canGetDamage)
        {
            for (int i = 0; i < hitBoxes.Length; i++)
            {
                hitBoxes[i].SetActive(false);
            }
            
        }
    }


    public Transform getNearestShootingPoint()
    {
        Transform tMin = null;
        float minDist = Mathf.Infinity;
        Vector3 currentPos = playerBase.gameObject.transform.position;
        foreach (Transform t in shootPositions)
        {
            float dist = Vector3.Distance(t.position, currentPos);
            if (dist < minDist)
            {
                tMin = t;
                minDist = dist;
            }
        }

        shootPos = tMin;

        return tMin;

    }

    public void getFurthestHitBox()
    {
        GameObject tMax = null;
        float maxDist = 0;
        Vector3 currentPos = playerBase.gameObject.transform.position;
        foreach (GameObject t in hitBoxes)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist > maxDist)
            {
                tMax = t;
                maxDist = dist;
            }
        }

        furthestHitBox = tMax;

        for (int i = 0; i < hitBoxes.Length; i++)
        {
            if (hitBoxes[i] == tMax)
                hitBoxes[i].SetActive(true);
            else
                hitBoxes[i].SetActive(false);
        }

    }


    public IEnumerator BurstFire(int bulletCount, int burstRounds, float burstCooldown, float bulletSpeed, float shootSpread, float spreadIncrease, float[] sinCurveForce, float sinCurveValue, bool addForce)
    {

        var shootAngleVec = shootPos.position - turretMittlePoint.position;

        var currentSinCurve = 0;

        for (int i = 0; i < burstRounds; i++)
        {

            var shootAngle = Mathf.Atan2(shootAngleVec.y, shootAngleVec.x) * Mathf.Rad2Deg - shootSpread;

            camShake.DoNoise(2.5f, 2.5f, 0.3f);

            var newPart = Instantiate(shootParticle, shootPos.transform.position, Quaternion.identity);

            newPart.transform.eulerAngles = new Vector3(0,0,shootPos.transform.eulerAngles.z + -90);

            newPart.GetComponent<SelfDestruct>().time = 3;

            bossshot.Play();

            for (int j = 0; j < bulletCount; j++)
            {
                GameObject bulletClone = Instantiate(bulletPref, shootPos.transform.position, Quaternion.identity);

                Rigidbody2D bulletRB = bulletClone.GetComponent<Rigidbody2D>();

                bulletClone.GetComponent<bulletScript>().addForce = addForce;
                bulletClone.GetComponent<bulletScript>().force = sinCurveForce[currentSinCurve];
                bulletClone.GetComponent<bulletScript>().addAngleValue = sinCurveValue;

                bulletClone.transform.eulerAngles = new Vector3(0, 0, shootAngle);

                shootAngle += spreadIncrease;

                bulletRB.AddForce(bulletClone.transform.right * bulletSpeed, ForceMode2D.Impulse);
            }

            if (currentSinCurve < burstRounds)
                currentSinCurve++;


            yield return new WaitForSecondsRealtime(burstCooldown);

        }

        
        finishedBurstFire = true;

    }


    public IEnumerator SlamAttack()
    {
        slamHitBox.SetActive(true);
        camShake.DoNoise(3, 3, 0.4f);
        bossSlam.Play();
        yield return new WaitForSeconds(0.1f);
        slamHitBox.SetActive(false);

        anim.SetTrigger("StopAttack");

    }


    public void SpawnMinion(GameObject[] spawnPoints, int ammount, Transform playerPos, float spawnCancelRange, GameObject enemyPrefab, float spawnDelay)
    {
        StartCoroutine(SpawnMinionEnu(spawnPoints, ammount, playerPos, spawnCancelRange, enemyPrefab, spawnDelay));
    }

    public IEnumerator SpawnMinionEnu(GameObject[] spawnPoints, int ammount, Transform playerPos, float spawnCancelRange, GameObject enemyPrefab, float spawnDelay)
    {
        var ammountSpawned = 0;

        var randomSpawn = 0;

        for (int i = 0; i < ammount; i++)
        {
            
            var playerDistance = Vector2.Distance(spawnPoints[randomSpawn].transform.position, playerPos.position);

            if (playerDistance > spawnCancelRange)
            {
                Instantiate(enemyPrefab, spawnPoints[randomSpawn].transform.position, Quaternion.identity);
                ammountSpawned++;

                if (ammountSpawned >= ammount)
                    anim.SetTrigger("StopAttack");

            }
            else
            {
                i--;
            }

            if (randomSpawn == spawnPoints.Length - 1)
                randomSpawn = 0;
            else
                randomSpawn += 1;

            yield return new WaitForSecondsRealtime(spawnDelay);

        }
    }




    public void StompParticle()
    {
        slamPart1.Play();
        slamPart2.Play();

        camShake.DoNoise(2.5f, 2.5f, 0.7f);

        spawnMinionSound.Play();

    }

    public void SlamParticle()
    {
     
        slamPart3.Play();
        camShake.DoNoise(2.5f, 2.5f, 0.7f);
    }

}
