using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletScript : MonoBehaviour
{

    public float addAngleValue;
    public float force;
    private Rigidbody2D rb;

    public bool isBoss;

    public ParticleSystem particleLand;

    public bool addForce;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        if (addForce)
        {

            transform.Rotate(new Vector3(0, 0, addAngleValue * Time.deltaTime));
            rb.AddForce(transform.up * force, ForceMode2D.Force);

        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player")){
            collision.GetComponent<PlayerHealth>().TakeDamange(1);
            var newPar = Instantiate(particleLand, transform.position, Quaternion.identity);
            newPar.GetComponent<SelfDestruct>().time = 1;
            Destroy(gameObject);
        }

        if (collision.CompareTag("Wall"))
        {
            var newPar = Instantiate(particleLand, transform.position, Quaternion.identity);
            newPar.GetComponent<SelfDestruct>().time = 1;
            Destroy(gameObject);
        }

        if(!isBoss)
        if (collision.CompareTag("BossBody"))
        {
            var newPar = Instantiate(particleLand, transform.position, Quaternion.identity);
            newPar.GetComponent<SelfDestruct>().time = 1;
            Destroy(gameObject);
        }
    }

}
