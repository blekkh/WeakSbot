using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_LaserAttack : StateMachineBehaviour
{

    public float laserSpeed;
    public float laserTime;
    private float currentLaserTime;
    private float laserAnticipationTime = 2;
    private float currentLaserAntiTime;
    private float laserDir = 1;
    public int damage;

    private Transform laserBase;
    private Transform laserStartPoint;

    private Prototype_Base _Base;

    

    public LayerMask layerMask;

    public bool canGetDamage;

    private ParticleSystem laserPar1;
    private ParticleSystem laserPar2;
    private GameObject burnParticle;

    private ParticleSystem bigLoadUp1;
    private ParticleSystem bigLoadUp2;

    private ParticleSystem laserBeamShootPar;


    private CameraShake camShake;

    private RaycastHit2D hit;

    private AudioSource biglaserSound;
    private AudioSource chargeUpSound;


    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        biglaserSound = GameObject.Find("biglaserSound").GetComponent<AudioSource>();
        chargeUpSound = GameObject.Find("bossloadup").GetComponent<AudioSource>();

        _Base = animator.GetComponent<Prototype_Base>();
        laserBase = _Base.laserBase;
        laserStartPoint = _Base.laserStartPoint;
        burnParticle = _Base.burnParticle;
        currentLaserAntiTime = laserAnticipationTime;
        currentLaserTime = laserTime;
        _Base.canGetDamage = canGetDamage;
        camShake = FindObjectOfType<CameraShake>();

        laserPar1 = _Base.laserPar1;
        laserPar2 = _Base.laserPar2;

        bigLoadUp1 = _Base.bigLoadUp1;
        bigLoadUp2 = _Base.bigLoadUp2;

        bigLoadUp1.gameObject.transform.position = laserStartPoint.position;
        bigLoadUp1.Play();

        bigLoadUp2.gameObject.transform.position = laserStartPoint.position;
        bigLoadUp2.Play();

        laserBeamShootPar = _Base.laserBeamShootPar;

        chargeUpSound.Play();

        biglaserSound.Play();

        getFurthestHitBoxForLaser();

        animator.SetFloat("VerticalPlayerPos", -1);
        animator.SetFloat("HorizontalPlayerPos", 0);

       

        laserDir *= Random.Range(0, 2) * 2 - 1;

        
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        if (currentLaserTime > 0)
        {

            if (currentLaserAntiTime > 0)
            {
                currentLaserAntiTime -= Time.deltaTime;
                bigLoadUp2.transform.localScale = new Vector2(bigLoadUp2.transform.localScale.y - Time.deltaTime * 1f, bigLoadUp2.transform.localScale.y - Time.deltaTime * 1f);
                camShake.DoNoise(1, 1, 1);
            }
            else
            {
                laserBeamShootPar.gameObject.SetActive(true);
                camShake.DoNoise(2, 2, 1);

                laserPar1.gameObject.SetActive(true);
                laserPar2.gameObject.SetActive(true);
                burnParticle.SetActive(true);


                bigLoadUp2.gameObject.SetActive(false);
                bigLoadUp1.Stop();
                bigLoadUp2.transform.localScale = new Vector2(1, 1);


                laserBase.transform.RotateAround(laserBase.position, new Vector3(0, 0, 20 * laserDir), Time.deltaTime * laserSpeed);

                hit = Physics2D.Raycast(laserStartPoint.position, laserStartPoint.right, 20, layerMask);

                animator.SetFloat("VerticalPlayerPos", hit.point.y);
                animator.SetFloat("HorizontalPlayerPos", hit.point.x);

                burnParticle.transform.position = hit.point;
                currentLaserTime -= Time.deltaTime;


                if (hit.transform.CompareTag("Player"))
                {
                    hit.transform.GetComponent<PlayerHealth>().TakeDamange(damage);
                }

                getFurthestHitBoxForLaser();

            }

        } 
        
        if(currentLaserTime <= 0)
        {
            animator.SetTrigger("StopAttack");
        }

        

    }


    public void getFurthestHitBoxForLaser()
    {
        GameObject tMax = null;
        float maxDist = 0;
        Vector3 currentPos = hit.point;
        foreach (GameObject t in _Base.hitBoxes)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist > maxDist)
            {
                tMax = t;
                maxDist = dist;
            }
        }

        _Base.furthestHitBox = tMax;

        for (int i = 0; i < _Base.hitBoxes.Length; i++)
        {
            if (_Base.hitBoxes[i] == tMax)
                _Base.hitBoxes[i].SetActive(true);
            else
                _Base.hitBoxes[i].SetActive(false);
        }

    }



    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        laserBeamShootPar.gameObject.SetActive(false);
        laserPar1.gameObject.SetActive(false);
        laserPar2.gameObject.SetActive(false);
        burnParticle.SetActive(false);
        bigLoadUp1.Stop();
        bigLoadUp2.Stop();
        laserBase.localEulerAngles = new Vector3(0, 0, 0);
        biglaserSound.Stop();
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
     
}
