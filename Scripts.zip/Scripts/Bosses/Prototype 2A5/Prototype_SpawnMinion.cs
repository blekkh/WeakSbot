using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_SpawnMinion : StateMachineBehaviour
{

    public GameObject enemyPrefab;
    public int ammount;

    private Transform playerPos;
    private float playerDistance;

    private GameObject[] spawnPoints;

    public float startSpawnDelay;
    private float currentStartSpawnDelay;
    public float spawnCancelRange;
    public float spawnDelay;

    private bool hasSpawned;

    public bool canGetDamage;

    private Prototype_Base _Base;




    //OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

   

        hasSpawned = false;

        currentStartSpawnDelay = startSpawnDelay;

        spawnPoints = GameObject.FindGameObjectsWithTag("SpawnPoint");

        playerPos = GameObject.FindGameObjectWithTag("Player").transform;

        animator.SetFloat("VerticalPlayerPos", -1);
        animator.SetFloat("HorizontalPlayerPos", 0);

        _Base = animator.GetComponent<Prototype_Base>();

        _Base.canGetDamage = canGetDamage;


        getFurthestHitBoxForMinion();



        

    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {


       
        if (currentStartSpawnDelay > 0)
        {
            currentStartSpawnDelay -= Time.deltaTime;
        } else if (currentStartSpawnDelay <= 0 && !hasSpawned)
        {
            hasSpawned = true;

            _Base.SpawnMinion(spawnPoints, ammount, playerPos, spawnCancelRange, enemyPrefab, spawnDelay);
        }

    }



    public void getFurthestHitBoxForMinion()
    {
        GameObject tMax = null;
        float maxDist = 0;
        Vector3 currentPos = new Vector3(0, -2, 0);
        foreach (GameObject t in _Base.hitBoxes)
        {
            float dist = Vector3.Distance(t.transform.position, currentPos);
            if (dist > maxDist)
            {
                tMax = t;
                maxDist = dist;
            }
        }

        _Base.furthestHitBox = tMax;

        for (int i = 0; i < _Base.hitBoxes.Length; i++)
        {
            if (_Base.hitBoxes[i] == tMax)
                _Base.hitBoxes[i].SetActive(true);
            else
                _Base.hitBoxes[i].SetActive(false);
        }

    }


    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
       
        


    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
