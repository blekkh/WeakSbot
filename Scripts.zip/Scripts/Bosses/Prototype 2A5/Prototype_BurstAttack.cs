using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Prototype_BurstAttack : StateMachineBehaviour
{

    public float anticipationTime;
    private float currentAnticipationTime;


    private Prototype_Base _Base;

    public int bulletCount;
    public float burstCoolDown;
    public int burstRounds;
    public float bulletSpeed;
    public float shootSpread;
    public float spreadIncrease;
    public float[] sinCurveForce;
    public float sinCurveValue;
    public bool addSinForce;


    private bool hasAttacked;

    private ParticleSystem anticipationParticle1;
    private ParticleSystem anticipationParticle2;

    public bool canGetDamage;

    private AudioSource bossLoadUp;



    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        bossLoadUp = GameObject.Find("bossloadup").GetComponent<AudioSource>();


        _Base = animator.GetComponent<Prototype_Base>();


        hasAttacked = false;

        currentAnticipationTime = anticipationTime;

        anticipationParticle1 = _Base.loadUpParticleSystem;

        anticipationParticle1.gameObject.transform.position = _Base.shootPos.position;
        anticipationParticle1.Play();

        anticipationParticle2 = _Base.loadUpParticleSystem2;
        anticipationParticle2.gameObject.SetActive(true);

        anticipationParticle2.gameObject.transform.position = _Base.shootPos.position;
        anticipationParticle2.Play();

        _Base.getFurthestHitBox();

        _Base.canGetDamage = canGetDamage;
        bossLoadUp.Play();

    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        if (currentAnticipationTime > 0)
        {
            currentAnticipationTime -= Time.deltaTime;
            anticipationParticle2.transform.localScale = new Vector2(anticipationParticle2.transform.localScale.y - Time.deltaTime * 1.5f, anticipationParticle2.transform.localScale.y - Time.deltaTime * 1.5f);
     
        }
        else if (currentAnticipationTime <= 0 && !hasAttacked)
        {
            hasAttacked = true;
            anticipationParticle1.Stop();
            anticipationParticle2.transform.localScale = new Vector2(1, 1);
            anticipationParticle2.gameObject.SetActive(false);
            _Base.StartCoroutine(_Base.BurstFire(bulletCount, burstRounds, burstCoolDown, bulletSpeed, shootSpread, spreadIncrease, sinCurveForce, sinCurveValue, addSinForce));
        }
            

        if (_Base.finishedBurstFire)
        {
            animator.SetTrigger("StopAttack");
         
        }  

    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        
    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
