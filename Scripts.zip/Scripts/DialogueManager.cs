using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    public GameObject DialogueBox;
    public TMP_Text dialogueText;

    public Animator anim;

    public PlayerBase _playerBase;

    private Queue<string> sentences;

    // Start is called before the first frame update
    void Start()
    {
        sentences = new Queue<string>();

        _playerBase = FindObjectOfType<PlayerBase>();
    }

    public void StartDialogue(Dialogue dialogue)
    {
        DialogueBox.SetActive(true);
        anim.SetBool("IsOpen", true);

        _playerBase.inDialogue = true;

        sentences.Clear();

        foreach (string sentence in dialogue.sentences)
        {
            sentences.Enqueue(sentence);
        }


        DisplayNextSenctence();
    }


    public void DisplayNextSenctence()
    {
        if(sentences.Count == 0)
        {
            EndDialogue();
            return;
        }

        string sentence = sentences.Dequeue();


        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));

    }

    IEnumerator TypeSentence (string sentence)
    {
        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text += letter;
            yield return null;
        }
    }

    public void EndDialogue()
    {
        anim.SetBool("IsOpen", false);
        _playerBase.inDialogue = false;
        DialogueBox.SetActive(false);
    }
}
